^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package segway_rmp
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.1.2 (2015-03-14)
------------------
* Merge pull request `#24 <https://github.com/segwayrmp/segway_rmp/issues/24>`_ from segwayrmp/piyushk/parametrize_frame_ids
  allow parametrizing odometry frame id as well (useful for multiple robots)
* Contributors: Piyush Khandelwal

0.1.1 (2013-05-18)
------------------
* Merge pull request `#12 <https://github.com/segwayrmp/segway_rmp/issues/12>`_ from segwayrmp/cleanup
  Clean up of build system
  - missing build_depend on message_generation
  - added repository url
  - use find_package on libsegwayrmp, not pkg-config
  - general CMakeLists.txt cleanup
  - add missing install target for node
  - removed old rosinstall file and mainpage.dox
* Contributors: Piyush Khandelwal, William Woodall

0.1.0 (2013-05-07)
------------------
* initial release.
* Contributors: Chien-Liang Fok, Piyush Khandelwal, William Woodall
