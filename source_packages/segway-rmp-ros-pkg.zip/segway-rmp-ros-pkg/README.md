[![Build Status](https://travis-ci.org/segwayrmp/segway-rmp-ros-pkg.png?branch=master)](https://travis-ci.org/segwayrmp/segway-rmp-ros-pkg)
